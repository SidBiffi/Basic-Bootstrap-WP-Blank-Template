	

	
	</div>

			<div class = "footer">

				<div class = "container">

						<p class = "navbar-text pull-left">© 2004 - 2016 Basics Corporation</p>

				</div>

			</div>	
		
	</body>
</html>