<!DOCTYPE html>
<html>
	<head>
		<title><?php bloginfo( 'name' ); ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href = "<?php bloginfo('stylesheet_url'); ?>" rel = "stylesheet">
		<?php wp_head(); ?>
	</head>
	<body>


			
			<div class = "header">

				<div class = "container">

						<p class = "navbar-text pull-left">HEADER</p>

				</div>

			</div>	
		
		<div class = "container">